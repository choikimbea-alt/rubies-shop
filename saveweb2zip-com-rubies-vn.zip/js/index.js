$(document).ready(function ($) {
	$('.section_base .button_show_tab').on('click', function(e){
		e.preventDefault();
		var $this = $(this);
		$this.parents('.section_base .section-head').find('.viewallcat').stop().slideToggle();
		$(this).toggleClass('active')
		return false;
	});
	$('.add_to_cart').click(function(e){	
		e.preventDefault();		
		var $this = $(this);
		var form = $this.parents('form');	
		$.ajax({
			type: 'POST',
			url: '/cart/add.js',
			async: false,
			data: form.serialize(),
			dataType: 'json',
			beforeSend: function() { },
			success: function(line_item) {
				ajaxCart.load();
				//$('.popup-cart-mobile, .backdrop__body-backdrop___1rvky').addClass('active');
				//AddCartMobile(line_item);
			},
			cache: false
		});
	});
});
/*tab*/
$(".not-dqtab").each( function(e){
	/*khai báo khởi tạo ban đầu cho 2 kiểu tab*/
	var $this1 = $(this);
	var $this2 = $(this);
	var datasection = $this1.closest('.not-dqtab').attr('data-section');
	$this1.find('.tabs-title .item:first-child').addClass('current');
	$this1.find('.tab-content').first().addClass('current');

	/*khai báo cho chức năng dành cho mobile tab*/
	var _this = $(this).find('.wrap_tab_index .title_module_main');
	var droptab = $(this).find('.link_tab_check_click');


	/*type 1*/ //kiểu 1 này thì load có owl carousel
	$this1.find('.tabtitle1.ajax .item').click(function(){
		var $this2 = $(this),
			tab_id = $this2.attr('data-tab'),
			url = $this2.attr('data-url');
		var etabs = $this2.closest('.e-tabs');
		etabs.find('.tab-viewall').attr('href',url);
		etabs.find('.tabs-title .item').removeClass('current');
		etabs.find('.tab-content').removeClass('current');
		$this2.addClass('current');
		etabs.find("."+tab_id).addClass('current');
		//Nếu đã load rồi thì không load nữa
		if(!$this2.hasClass('has-content')){
			$this2.addClass('has-content');		
			getContentTab(url,"."+ datasection+" ."+tab_id);
		}
	});


});
$(".not-dqtab2").each( function(e){
	/*khai báo khởi tạo ban đầu cho 2 kiểu tab*/
	var $this1 = $(this);
	var $this2 = $(this);
	var datasection = $this1.closest('.not-dqtab2').attr('data-section');
	$this1.find('.tabs-title .item:first-child').addClass('current');
	$this1.find('.tab-content').first().addClass('current');

	/*khai báo cho chức năng dành cho mobile tab*/
	var _this = $(this).find('.wrap_tab_index .title_module_main');
	var droptab = $(this).find('.link_tab_check_click_2');


	$this1.find('.tabtitle2.ajax .item').click(function(){
		document.getElementById("tab-time-1div").style.display = "block";
		var $this2 = $(this),
			tab_id = $this2.attr('data-tab'),
			url = $this2.attr('data-url');
		var etabs = $this2.closest('.e-tabs');
		etabs.find('.tab-viewall').attr('href',url);
		etabs.find('.tabs-title .item').removeClass('current');
		etabs.find('.tab-content').removeClass('current');
		$this2.addClass('current');

		etabs.find("."+tab_id).addClass('current');
		//Nếu đã load rồi thì không load nữa
		if(!$this2.hasClass('has-content')){
			$this2.addClass('has-content');		
			getContentTab2(url,"."+ datasection+" ."+tab_id);
		}
	});


});
$(".li-kmdiscount").click(function() {
	$('html, body').animate({
		scrollTop: $("#index_flash_sale").offset().top
	}, 1000);
});

// Get content cho tab
function getContentTab(url,selector){
	url = url+"?view=ajaxload";
	var loading = '<div class="a-center"><img src="//bizweb.dktcdn.net/100/462/587/themes/880841/assets/rolling.svg?1763366260362" alt="loading"/></div>';
	$.ajax({
		type: 'GET',
		url: url,
		beforeSend: function() {
			$(selector).html(loading);
		},
		success: function(data) {
			var content = $(data);
			setTimeout(function(){
				$(selector).html(content.html());
				$(selector+' .swiper-nth').each( function(){
					var swipertab = new Swiper('.swiper-nth', {
						slidesPerColumnFill: 'row',
						direction: 'horizontal',
						slidesPerView: 4,
						spaceBetween: 20,
						slidesPerGroup: 1,
						slidesPerColumn: 1,
						navigation: {
							nextEl: '.swiper-button-next',
							prevEl: '.swiper-button-prev',
						},
						breakpoints: {
							280: {
								slidesPerView: 'auto',
								spaceBetween: 15
							},
							640: {
								slidesPerView: 2,
								spaceBetween: 15
							},
							768: {
								slidesPerView: 3,
								spaceBetween: 15
							},
							992: {
								slidesPerView: 3,
								spaceBetween: 15
							},
							1024: {
								slidesPerView: 4,
								spaceBetween: 20
							}
						}
					});
				});
				awe_lazyloadImage();
				
				$(document).ready(function () {
					var modal = $('.quickview-product');
					var btn = $('.quick-view');
					var span = $('.quickview-close');

					btn.click(function () {
						modal.show();
					});

					span.click(function () {
						modal.hide();
					});

					$(window).on('click', function (e) {
						if ($(e.target).is('.modal')) {
							modal.hide();
						}
					});
				});
				
				$(selector+' .add_to_cart').click(function(e){	
					e.preventDefault();		
					var $this = $(this);
					var form = $this.parents('form');	
					$.ajax({
						type: 'POST',
						url: '/cart/add.js',
						async: false,
						data: form.serialize(),
						dataType: 'json',
						beforeSend: function() { },
						success: function(line_item) {
							ajaxCart.load();
							//$('.popup-cart-mobile, .backdrop__body-backdrop___1rvky').addClass('active');
							//AddCartMobile(line_item);
						},
						cache: false
					});
				});
			},100);
		},
		dataType: "html"


	});
}
// Get content cho tab
function getContentTab2(url,selector){
	url = url+"?view=ajaxload2";
	var loading = '<div class="a-center"><img src="//bizweb.dktcdn.net/100/462/587/themes/880841/assets/rolling.svg?1763366260362" alt="loading"/></div>';
	$.ajax({
		type: 'GET',
		url: url,
		beforeSend: function() {
			$(selector).html(loading);
		},
		success: function(data) {
			var content = $(data);
			setTimeout(function(){
				$(selector).html(content.html());
				awe_lazyloadImage();
				
				favoriBean.Wishlist.wishlistProduct();
				
				
				$(document).ready(function () {
					var modal = $('.quickview-product');
					var btn = $('.quick-view');
					var span = $('.quickview-close');

					btn.click(function () {
						modal.show();
					});

					span.click(function () {
						modal.hide();
					});

					$(window).on('click', function (e) {
						if ($(e.target).is('.modal')) {
							modal.hide();
						}
					});
				});
				
				$(selector+' .add_to_cart').click(function(e){	
					e.preventDefault();		
					var $this = $(this);
					var form = $this.parents('form');	
					$.ajax({
						type: 'POST',
						url: '/cart/add.js',
						async: false,
						data: form.serialize(),
						dataType: 'json',
						beforeSend: function() { },
						success: function(line_item) {
							ajaxCart.load();
						//	$('.popup-cart-mobile, .backdrop__body-backdrop___1rvky').addClass('active');
							//AddCartMobile(line_item);
						},
						cache: false
					});
				});
			},100);
		},
		dataType: "html"


	});
}
// Ajax carousel

var swipertab = new Swiper('.swiper-first', {
	slidesPerColumnFill: 'row',
	direction: 'horizontal',
	slidesPerView: 4,
	spaceBetween: 20,
	slidesPerGroup: 1,
	slidesPerColumn: 1,
	navigation: {
		nextEl: '.swiper-button-next',
		prevEl: '.swiper-button-prev',
	},
	breakpoints: {
		280: {
			slidesPerView: 'auto',
			spaceBetween: 15
		},
		640: {
			slidesPerView: 2,
			spaceBetween: 15
		},
		768: {
			slidesPerView: 3,
			spaceBetween: 15
		},
		992: {
			slidesPerView: 3,
			spaceBetween: 15
		},
		1024: {
			slidesPerView: 4,
			spaceBetween: 20
		}
	}
});